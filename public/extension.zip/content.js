console.log("Content script injected!");

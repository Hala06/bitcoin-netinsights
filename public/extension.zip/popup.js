document.addEventListener("DOMContentLoaded", () => {
  updateStats();

  document.getElementById("refresh").addEventListener("click", () => {
    updateStats();
  });
});

function updateStats() {
  // Replace these with actual API calls later
  document.getElementById("fees").innerText = "High: 34 sat/vB, Low: 6 sat/vB";
  document.getElementById("opreturn").innerText = "182 OP_Return txs today";
  document.getElementById("status").innerText = "Healthy ✅";
}
